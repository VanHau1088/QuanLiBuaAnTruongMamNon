﻿
namespace QLBA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.trangChủToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTrẻToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xếpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinPhụHuynhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kHỐIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinGiáoViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHỰCĐƠNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHỰCĐƠNToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đĂNGKÝToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trangChủToolStripMenuItem,
            this.kHỐIToolStripMenuItem,
            this.tHỰCĐƠNToolStripMenuItem,
            this.đĂNGKÝToolStripMenuItem,
            this.toolStripMenuItem2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1344, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // trangChủToolStripMenuItem
            // 
            this.trangChủToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("trangChủToolStripMenuItem.BackgroundImage")));
            this.trangChủToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinTrẻToolStripMenuItem,
            this.xếpToolStripMenuItem,
            this.thôngTinPhụHuynhToolStripMenuItem});
            this.trangChủToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("trangChủToolStripMenuItem.Image")));
            this.trangChủToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.trangChủToolStripMenuItem.Name = "trangChủToolStripMenuItem";
            this.trangChủToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.trangChủToolStripMenuItem.Text = "QUẢN LÍ TRẺ";
            this.trangChủToolStripMenuItem.Click += new System.EventHandler(this.trangChủToolStripMenuItem_Click);
            // 
            // thôngTinTrẻToolStripMenuItem
            // 
            this.thôngTinTrẻToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thôngTinTrẻToolStripMenuItem.Image")));
            this.thôngTinTrẻToolStripMenuItem.Name = "thôngTinTrẻToolStripMenuItem";
            this.thôngTinTrẻToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.thôngTinTrẻToolStripMenuItem.Text = "Thông tin trẻ";
            this.thôngTinTrẻToolStripMenuItem.Click += new System.EventHandler(this.thôngTinTrẻToolStripMenuItem_Click);
            // 
            // xếpToolStripMenuItem
            // 
            this.xếpToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("xếpToolStripMenuItem.Image")));
            this.xếpToolStripMenuItem.Name = "xếpToolStripMenuItem";
            this.xếpToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.xếpToolStripMenuItem.Text = "Khối - Lớp";
            this.xếpToolStripMenuItem.Click += new System.EventHandler(this.xếpToolStripMenuItem_Click_1);
            // 
            // thôngTinPhụHuynhToolStripMenuItem
            // 
            this.thôngTinPhụHuynhToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thôngTinPhụHuynhToolStripMenuItem.Image")));
            this.thôngTinPhụHuynhToolStripMenuItem.Name = "thôngTinPhụHuynhToolStripMenuItem";
            this.thôngTinPhụHuynhToolStripMenuItem.Size = new System.Drawing.Size(227, 26);
            this.thôngTinPhụHuynhToolStripMenuItem.Text = "Thông tin phụ huynh";
            this.thôngTinPhụHuynhToolStripMenuItem.Click += new System.EventHandler(this.thôngTinPhụHuynhToolStripMenuItem_Click);
            // 
            // kHỐIToolStripMenuItem
            // 
            this.kHỐIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.thôngTinGiáoViênToolStripMenuItem});
            this.kHỐIToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("kHỐIToolStripMenuItem.Image")));
            this.kHỐIToolStripMenuItem.Name = "kHỐIToolStripMenuItem";
            this.kHỐIToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.kHỐIToolStripMenuItem.Text = "QUẢN LÝ GIÁO VIÊN";
            this.kHỐIToolStripMenuItem.Click += new System.EventHandler(this.kHỐIToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(220, 26);
            this.toolStripMenuItem1.Text = "Phân Công";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // thôngTinGiáoViênToolStripMenuItem
            // 
            this.thôngTinGiáoViênToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thôngTinGiáoViênToolStripMenuItem.Image")));
            this.thôngTinGiáoViênToolStripMenuItem.Name = "thôngTinGiáoViênToolStripMenuItem";
            this.thôngTinGiáoViênToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.thôngTinGiáoViênToolStripMenuItem.Text = "Thông tin giáo viên";
            this.thôngTinGiáoViênToolStripMenuItem.Click += new System.EventHandler(this.thôngTinGiáoViênToolStripMenuItem_Click_1);
            // 
            // tHỰCĐƠNToolStripMenuItem
            // 
            this.tHỰCĐƠNToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tHỰCĐƠNToolStripMenuItem1});
            this.tHỰCĐƠNToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tHỰCĐƠNToolStripMenuItem.Image")));
            this.tHỰCĐƠNToolStripMenuItem.Name = "tHỰCĐƠNToolStripMenuItem";
            this.tHỰCĐƠNToolStripMenuItem.Size = new System.Drawing.Size(159, 24);
            this.tHỰCĐƠNToolStripMenuItem.Text = "QUẢN LÍ BỮA ĂN";
            this.tHỰCĐƠNToolStripMenuItem.Click += new System.EventHandler(this.tHỰCĐƠNToolStripMenuItem_Click);
            // 
            // tHỰCĐƠNToolStripMenuItem1
            // 
            this.tHỰCĐƠNToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("tHỰCĐƠNToolStripMenuItem1.Image")));
            this.tHỰCĐƠNToolStripMenuItem1.Name = "tHỰCĐƠNToolStripMenuItem1";
            this.tHỰCĐƠNToolStripMenuItem1.Size = new System.Drawing.Size(205, 26);
            this.tHỰCĐƠNToolStripMenuItem1.Text = "Thông tin bữa ăn";
            this.tHỰCĐƠNToolStripMenuItem1.Click += new System.EventHandler(this.tHỰCĐƠNToolStripMenuItem1_Click);
            // 
            // đĂNGKÝToolStripMenuItem
            // 
            this.đĂNGKÝToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngNhậpToolStripMenuItem,
            this.tàiKhoảnToolStripMenuItem});
            this.đĂNGKÝToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("đĂNGKÝToolStripMenuItem.Image")));
            this.đĂNGKÝToolStripMenuItem.Name = "đĂNGKÝToolStripMenuItem";
            this.đĂNGKÝToolStripMenuItem.Size = new System.Drawing.Size(181, 24);
            this.đĂNGKÝToolStripMenuItem.Text = "QUẢN LÍ TÀI KHOẢN";
            // 
            // đăngNhậpToolStripMenuItem
            // 
            this.đăngNhậpToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("đăngNhậpToolStripMenuItem.Image")));
            this.đăngNhậpToolStripMenuItem.Name = "đăngNhậpToolStripMenuItem";
            this.đăngNhậpToolStripMenuItem.Size = new System.Drawing.Size(168, 26);
            this.đăngNhậpToolStripMenuItem.Text = "Đăng Nhập";
            this.đăngNhậpToolStripMenuItem.Click += new System.EventHandler(this.đăngNhậpToolStripMenuItem_Click);
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tàiKhoảnToolStripMenuItem.Image")));
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(168, 26);
            this.tàiKhoảnToolStripMenuItem.Text = "Tài Khoản";
            this.tàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.tàiKhoảnToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(14, 24);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1344, 809);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Phần mềm quản lý các bửa ăn của trường mẫu giáo 19-5: 52000887 + 52000883";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem trangChủToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kHỐIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHỰCĐƠNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHỰCĐƠNToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem đĂNGKÝToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTrẻToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xếpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem thôngTinGiáoViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinPhụHuynhToolStripMenuItem;
    }
}

