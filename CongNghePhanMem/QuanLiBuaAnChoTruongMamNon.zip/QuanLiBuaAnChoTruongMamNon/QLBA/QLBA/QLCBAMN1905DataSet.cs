﻿namespace QLBA
{


    partial class QLCBAMN1905DataSet
    {
        partial class DATATABLE2DataTable
        {
        }
    }
}
