﻿namespace QLBA
{
    partial class QuanLiBuaAn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.bt_Sua = new System.Windows.Forms.Button();
            this.bt_Xoa = new System.Windows.Forms.Button();
            this.bt_Them = new System.Windows.Forms.Button();
            this.txt_TongChiPhi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_CpChieu = new System.Windows.Forms.TextBox();
            this.txt_CpTrua = new System.Windows.Forms.TextBox();
            this.txt_CpSang = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rtxt_BuaChieu = new System.Windows.Forms.RichTextBox();
            this.rtxt_BuaTrua = new System.Windows.Forms.RichTextBox();
            this.rtxt_BuaSang = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtp_NgayThangNam = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grp_TTBA = new System.Windows.Forms.GroupBox();
            this.txt_MaLop = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Gridview1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.grp_TTBA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label10.Location = new System.Drawing.Point(38, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(732, 90);
            this.label10.TabIndex = 0;
            this.label10.Text = "QUẢN LÝ BỮA ĂN";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(730, 388);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(87, 16);
            this.linkLabel1.TabIndex = 42;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Xem báo cáo";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // bt_Sua
            // 
            this.bt_Sua.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Sua.Location = new System.Drawing.Point(650, 330);
            this.bt_Sua.Name = "bt_Sua";
            this.bt_Sua.Size = new System.Drawing.Size(108, 50);
            this.bt_Sua.TabIndex = 41;
            this.bt_Sua.Text = "Sửa";
            this.bt_Sua.UseVisualStyleBackColor = true;
            this.bt_Sua.Click += new System.EventHandler(this.bt_Sua_Click);
            // 
            // bt_Xoa
            // 
            this.bt_Xoa.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Xoa.Location = new System.Drawing.Point(548, 330);
            this.bt_Xoa.Name = "bt_Xoa";
            this.bt_Xoa.Size = new System.Drawing.Size(80, 50);
            this.bt_Xoa.TabIndex = 40;
            this.bt_Xoa.Text = "Xóa";
            this.bt_Xoa.UseVisualStyleBackColor = true;
            this.bt_Xoa.Click += new System.EventHandler(this.bt_Xoa_Click);
            // 
            // bt_Them
            // 
            this.bt_Them.BackColor = System.Drawing.Color.Transparent;
            this.bt_Them.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Them.ForeColor = System.Drawing.Color.MediumBlue;
            this.bt_Them.Location = new System.Drawing.Point(402, 330);
            this.bt_Them.Name = "bt_Them";
            this.bt_Them.Size = new System.Drawing.Size(130, 50);
            this.bt_Them.TabIndex = 39;
            this.bt_Them.Text = "Thêm";
            this.bt_Them.UseVisualStyleBackColor = false;
            this.bt_Them.Click += new System.EventHandler(this.bt_Them_Click);
            // 
            // txt_TongChiPhi
            // 
            this.txt_TongChiPhi.Enabled = false;
            this.txt_TongChiPhi.Location = new System.Drawing.Point(114, 367);
            this.txt_TongChiPhi.Name = "txt_TongChiPhi";
            this.txt_TongChiPhi.Size = new System.Drawing.Size(240, 22);
            this.txt_TongChiPhi.TabIndex = 38;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 370);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 16);
            this.label9.TabIndex = 37;
            this.label9.Text = "Tổng chi phí :";
            // 
            // txt_CpChieu
            // 
            this.txt_CpChieu.Location = new System.Drawing.Point(506, 297);
            this.txt_CpChieu.Name = "txt_CpChieu";
            this.txt_CpChieu.Size = new System.Drawing.Size(138, 22);
            this.txt_CpChieu.TabIndex = 36;
            this.txt_CpChieu.TextChanged += new System.EventHandler(this.txt_CpChieu_TextChanged);
            this.txt_CpChieu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CpChieu_KeyPress);
            // 
            // txt_CpTrua
            // 
            this.txt_CpTrua.Location = new System.Drawing.Point(502, 194);
            this.txt_CpTrua.Name = "txt_CpTrua";
            this.txt_CpTrua.Size = new System.Drawing.Size(138, 22);
            this.txt_CpTrua.TabIndex = 35;
            this.txt_CpTrua.TextChanged += new System.EventHandler(this.txt_CpTrua_TextChanged);
            this.txt_CpTrua.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CpTrua_KeyPress);
            // 
            // txt_CpSang
            // 
            this.txt_CpSang.Location = new System.Drawing.Point(502, 95);
            this.txt_CpSang.Name = "txt_CpSang";
            this.txt_CpSang.Size = new System.Drawing.Size(138, 22);
            this.txt_CpSang.TabIndex = 34;
            this.txt_CpSang.TextChanged += new System.EventHandler(this.txt_CpSang_TextChanged);
            this.txt_CpSang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_CpSang_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(378, 300);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 16);
            this.label8.TabIndex = 33;
            this.label8.Text = "Chi phí bữa chiều :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(380, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 16);
            this.label7.TabIndex = 32;
            this.label7.Text = "Chi phí bữa trưa :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(378, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 16);
            this.label6.TabIndex = 31;
            this.label6.Text = "Chi phí bữa sáng :";
            // 
            // rtxt_BuaChieu
            // 
            this.rtxt_BuaChieu.Enabled = false;
            this.rtxt_BuaChieu.Location = new System.Drawing.Point(92, 265);
            this.rtxt_BuaChieu.Name = "rtxt_BuaChieu";
            this.rtxt_BuaChieu.Size = new System.Drawing.Size(262, 96);
            this.rtxt_BuaChieu.TabIndex = 30;
            this.rtxt_BuaChieu.Text = "";
            // 
            // rtxt_BuaTrua
            // 
            this.rtxt_BuaTrua.Enabled = false;
            this.rtxt_BuaTrua.Location = new System.Drawing.Point(92, 163);
            this.rtxt_BuaTrua.Name = "rtxt_BuaTrua";
            this.rtxt_BuaTrua.Size = new System.Drawing.Size(262, 96);
            this.rtxt_BuaTrua.TabIndex = 29;
            this.rtxt_BuaTrua.Text = "";
            // 
            // rtxt_BuaSang
            // 
            this.rtxt_BuaSang.Enabled = false;
            this.rtxt_BuaSang.Location = new System.Drawing.Point(92, 61);
            this.rtxt_BuaSang.Name = "rtxt_BuaSang";
            this.rtxt_BuaSang.Size = new System.Drawing.Size(262, 96);
            this.rtxt_BuaSang.TabIndex = 28;
            this.rtxt_BuaSang.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 16);
            this.label5.TabIndex = 27;
            this.label5.Text = "Bữa chiều :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "Bữa trưa :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "Bữa sáng :";
            // 
            // dtp_NgayThangNam
            // 
            this.dtp_NgayThangNam.CustomFormat = "dd/MM/yyyy";
            this.dtp_NgayThangNam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_NgayThangNam.Location = new System.Drawing.Point(495, 28);
            this.dtp_NgayThangNam.Name = "dtp_NgayThangNam";
            this.dtp_NgayThangNam.Size = new System.Drawing.Size(145, 22);
            this.dtp_NgayThangNam.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(375, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Ngày/tháng/năm :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.label10);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(445, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 132);
            this.panel1.TabIndex = 34;
            // 
            // grp_TTBA
            // 
            this.grp_TTBA.BackColor = System.Drawing.Color.Transparent;
            this.grp_TTBA.Controls.Add(this.txt_MaLop);
            this.grp_TTBA.Controls.Add(this.linkLabel1);
            this.grp_TTBA.Controls.Add(this.bt_Sua);
            this.grp_TTBA.Controls.Add(this.bt_Xoa);
            this.grp_TTBA.Controls.Add(this.bt_Them);
            this.grp_TTBA.Controls.Add(this.txt_TongChiPhi);
            this.grp_TTBA.Controls.Add(this.label9);
            this.grp_TTBA.Controls.Add(this.txt_CpChieu);
            this.grp_TTBA.Controls.Add(this.txt_CpTrua);
            this.grp_TTBA.Controls.Add(this.txt_CpSang);
            this.grp_TTBA.Controls.Add(this.label8);
            this.grp_TTBA.Controls.Add(this.label7);
            this.grp_TTBA.Controls.Add(this.label6);
            this.grp_TTBA.Controls.Add(this.rtxt_BuaChieu);
            this.grp_TTBA.Controls.Add(this.rtxt_BuaTrua);
            this.grp_TTBA.Controls.Add(this.rtxt_BuaSang);
            this.grp_TTBA.Controls.Add(this.label5);
            this.grp_TTBA.Controls.Add(this.label4);
            this.grp_TTBA.Controls.Add(this.label3);
            this.grp_TTBA.Controls.Add(this.dtp_NgayThangNam);
            this.grp_TTBA.Controls.Add(this.label2);
            this.grp_TTBA.Controls.Add(this.label1);
            this.grp_TTBA.ForeColor = System.Drawing.Color.MediumBlue;
            this.grp_TTBA.Location = new System.Drawing.Point(86, 200);
            this.grp_TTBA.Name = "grp_TTBA";
            this.grp_TTBA.Size = new System.Drawing.Size(817, 404);
            this.grp_TTBA.TabIndex = 33;
            this.grp_TTBA.TabStop = false;
            this.grp_TTBA.Text = "Thông tin bữa ăn hàng ngày";
            // 
            // txt_MaLop
            // 
            this.txt_MaLop.Enabled = false;
            this.txt_MaLop.Location = new System.Drawing.Point(92, 28);
            this.txt_MaLop.Margin = new System.Windows.Forms.Padding(4);
            this.txt_MaLop.Name = "txt_MaLop";
            this.txt_MaLop.Size = new System.Drawing.Size(161, 22);
            this.txt_MaLop.TabIndex = 54;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 16);
            this.label1.TabIndex = 22;
            this.label1.Text = "Tên lớp :";
            // 
            // Gridview1
            // 
            this.Gridview1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Gridview1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Gridview1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gridview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gridview1.Location = new System.Drawing.Point(925, 209);
            this.Gridview1.Name = "Gridview1";
            this.Gridview1.RowHeadersWidth = 51;
            this.Gridview1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Gridview1.Size = new System.Drawing.Size(853, 395);
            this.Gridview1.TabIndex = 35;
            this.Gridview1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gridview1_CellClick);
            this.Gridview1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gridview1_CellContentClick);
            // 
            // QuanLiBuaAn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1790, 696);
            this.Controls.Add(this.Gridview1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grp_TTBA);
            this.Name = "QuanLiBuaAn";
            this.Text = "QuanLiBuaAn: 52000887 + 52000883";
            this.Load += new System.EventHandler(this.QuanLiBuaAn_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.QuanLiBuaAn_Paint);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grp_TTBA.ResumeLayout(false);
            this.grp_TTBA.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button bt_Sua;
        private System.Windows.Forms.Button bt_Xoa;
        private System.Windows.Forms.Button bt_Them;
        private System.Windows.Forms.TextBox txt_TongChiPhi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_CpChieu;
        private System.Windows.Forms.TextBox txt_CpTrua;
        private System.Windows.Forms.TextBox txt_CpSang;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox rtxt_BuaChieu;
        private System.Windows.Forms.RichTextBox rtxt_BuaTrua;
        private System.Windows.Forms.RichTextBox rtxt_BuaSang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtp_NgayThangNam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grp_TTBA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_MaLop;
        private System.Windows.Forms.DataGridView Gridview1;
    }
}