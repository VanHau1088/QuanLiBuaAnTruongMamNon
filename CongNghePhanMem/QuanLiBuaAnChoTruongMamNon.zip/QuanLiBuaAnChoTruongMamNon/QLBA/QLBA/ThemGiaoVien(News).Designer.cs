﻿namespace QLBA
{
    partial class ThemGiaoVien_News_
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemGiaoVien_News_));
            this.grp_KhoiHoc = new System.Windows.Forms.GroupBox();
            this.bt_ChonAnh = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.imgBox = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ts_ChucNang = new System.Windows.Forms.ToolStrip();
            this.bt_Them = new System.Windows.Forms.ToolStripButton();
            this.bt_Xóa = new System.Windows.Forms.ToolStripButton();
            this.bt_Sửa = new System.Windows.Forms.ToolStripButton();
            this.Gridview1 = new System.Windows.Forms.DataGridView();
            this.txt_MaLop = new System.Windows.Forms.TextBox();
            this.lbl_MaLop = new System.Windows.Forms.Label();
            this.cbb_TrinhDo = new System.Windows.Forms.ComboBox();
            this.lbl_TrinhDo = new System.Windows.Forms.Label();
            this.txt_SDT = new System.Windows.Forms.TextBox();
            this.lbl_SDT = new System.Windows.Forms.Label();
            this.txt_CMND = new System.Windows.Forms.TextBox();
            this.lbl_CMND = new System.Windows.Forms.Label();
            this.txt_LuongCB = new System.Windows.Forms.TextBox();
            this.lbl_LuongCB = new System.Windows.Forms.Label();
            this.txt_HSL = new System.Windows.Forms.TextBox();
            this.lbl_HSL = new System.Windows.Forms.Label();
            this.txt_DiaChi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_GT = new System.Windows.Forms.TextBox();
            this.dtp_NgayVaoLam = new System.Windows.Forms.DateTimePicker();
            this.lbl_NgayVaoLam = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NgayThangNam = new System.Windows.Forms.DateTimePicker();
            this.txt_TenGV = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_MaGV = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grp_KhoiHoc.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).BeginInit();
            this.ts_ChucNang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).BeginInit();
            this.SuspendLayout();
            // 
            // grp_KhoiHoc
            // 
            this.grp_KhoiHoc.BackColor = System.Drawing.Color.Transparent;
            this.grp_KhoiHoc.Controls.Add(this.bt_ChonAnh);
            this.grp_KhoiHoc.Controls.Add(this.panel1);
            this.grp_KhoiHoc.Controls.Add(this.ts_ChucNang);
            this.grp_KhoiHoc.Controls.Add(this.Gridview1);
            this.grp_KhoiHoc.Controls.Add(this.txt_MaLop);
            this.grp_KhoiHoc.Controls.Add(this.lbl_MaLop);
            this.grp_KhoiHoc.Controls.Add(this.cbb_TrinhDo);
            this.grp_KhoiHoc.Controls.Add(this.lbl_TrinhDo);
            this.grp_KhoiHoc.Controls.Add(this.txt_SDT);
            this.grp_KhoiHoc.Controls.Add(this.lbl_SDT);
            this.grp_KhoiHoc.Controls.Add(this.txt_CMND);
            this.grp_KhoiHoc.Controls.Add(this.lbl_CMND);
            this.grp_KhoiHoc.Controls.Add(this.txt_LuongCB);
            this.grp_KhoiHoc.Controls.Add(this.lbl_LuongCB);
            this.grp_KhoiHoc.Controls.Add(this.txt_HSL);
            this.grp_KhoiHoc.Controls.Add(this.lbl_HSL);
            this.grp_KhoiHoc.Controls.Add(this.txt_DiaChi);
            this.grp_KhoiHoc.Controls.Add(this.label5);
            this.grp_KhoiHoc.Controls.Add(this.txt_GT);
            this.grp_KhoiHoc.Controls.Add(this.dtp_NgayVaoLam);
            this.grp_KhoiHoc.Controls.Add(this.lbl_NgayVaoLam);
            this.grp_KhoiHoc.Controls.Add(this.label4);
            this.grp_KhoiHoc.Controls.Add(this.label3);
            this.grp_KhoiHoc.Controls.Add(this.txt_NgayThangNam);
            this.grp_KhoiHoc.Controls.Add(this.txt_TenGV);
            this.grp_KhoiHoc.Controls.Add(this.label2);
            this.grp_KhoiHoc.Controls.Add(this.txt_MaGV);
            this.grp_KhoiHoc.Controls.Add(this.label1);
            this.grp_KhoiHoc.Dock = System.Windows.Forms.DockStyle.Left;
            this.grp_KhoiHoc.ForeColor = System.Drawing.Color.Blue;
            this.grp_KhoiHoc.Location = new System.Drawing.Point(0, 0);
            this.grp_KhoiHoc.Margin = new System.Windows.Forms.Padding(4);
            this.grp_KhoiHoc.Name = "grp_KhoiHoc";
            this.grp_KhoiHoc.Padding = new System.Windows.Forms.Padding(4);
            this.grp_KhoiHoc.Size = new System.Drawing.Size(1911, 785);
            this.grp_KhoiHoc.TabIndex = 1;
            this.grp_KhoiHoc.TabStop = false;
            this.grp_KhoiHoc.Text = "Thêm Giáo Viên";
            // 
            // bt_ChonAnh
            // 
            this.bt_ChonAnh.Location = new System.Drawing.Point(1385, 192);
            this.bt_ChonAnh.Margin = new System.Windows.Forms.Padding(4);
            this.bt_ChonAnh.Name = "bt_ChonAnh";
            this.bt_ChonAnh.Size = new System.Drawing.Size(196, 34);
            this.bt_ChonAnh.TabIndex = 55;
            this.bt_ChonAnh.Text = "Chọn ảnh...";
            this.bt_ChonAnh.UseVisualStyleBackColor = true;
            this.bt_ChonAnh.Click += new System.EventHandler(this.bt_ChonAnh_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.imgBox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(316, 32);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1294, 156);
            this.panel1.TabIndex = 54;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // imgBox
            // 
            this.imgBox.BackColor = System.Drawing.Color.Honeydew;
            this.imgBox.Location = new System.Drawing.Point(1053, 0);
            this.imgBox.Margin = new System.Windows.Forms.Padding(4);
            this.imgBox.Name = "imgBox";
            this.imgBox.Size = new System.Drawing.Size(237, 152);
            this.imgBox.TabIndex = 38;
            this.imgBox.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label6.Location = new System.Drawing.Point(98, 30);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(857, 90);
            this.label6.TabIndex = 0;
            this.label6.Text = "QUẢN LÝ GIÁO VIÊN";
            // 
            // ts_ChucNang
            // 
            this.ts_ChucNang.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ts_ChucNang.AutoSize = false;
            this.ts_ChucNang.BackColor = System.Drawing.Color.Honeydew;
            this.ts_ChucNang.Dock = System.Windows.Forms.DockStyle.None;
            this.ts_ChucNang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ts_ChucNang.GripMargin = new System.Windows.Forms.Padding(4);
            this.ts_ChucNang.ImageScalingSize = new System.Drawing.Size(100, 100);
            this.ts_ChucNang.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ts_ChucNang.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bt_Them,
            this.bt_Xóa,
            this.bt_Sửa});
            this.ts_ChucNang.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.ts_ChucNang.Location = new System.Drawing.Point(18, 47);
            this.ts_ChucNang.Name = "ts_ChucNang";
            this.ts_ChucNang.Size = new System.Drawing.Size(168, 474);
            this.ts_ChucNang.TabIndex = 53;
            // 
            // bt_Them
            // 
            this.bt_Them.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Them.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bt_Them.Image = ((System.Drawing.Image)(resources.GetObject("bt_Them.Image")));
            this.bt_Them.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bt_Them.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bt_Them.Name = "bt_Them";
            this.bt_Them.Size = new System.Drawing.Size(104, 127);
            this.bt_Them.Text = "Thêm";
            this.bt_Them.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Them.Click += new System.EventHandler(this.tSb_Them_Click);
            // 
            // bt_Xóa
            // 
            this.bt_Xóa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Xóa.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bt_Xóa.Image = ((System.Drawing.Image)(resources.GetObject("bt_Xóa.Image")));
            this.bt_Xóa.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bt_Xóa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bt_Xóa.Name = "bt_Xóa";
            this.bt_Xóa.Size = new System.Drawing.Size(104, 127);
            this.bt_Xóa.Text = "Xóa";
            this.bt_Xóa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Xóa.Click += new System.EventHandler(this.tSb_Xoa_Click);
            // 
            // bt_Sửa
            // 
            this.bt_Sửa.BackColor = System.Drawing.Color.Honeydew;
            this.bt_Sửa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Sửa.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bt_Sửa.Image = ((System.Drawing.Image)(resources.GetObject("bt_Sửa.Image")));
            this.bt_Sửa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bt_Sửa.Name = "bt_Sửa";
            this.bt_Sửa.Size = new System.Drawing.Size(104, 127);
            this.bt_Sửa.Text = "Sửa";
            this.bt_Sửa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Sửa.Click += new System.EventHandler(this.tSb_Sua_Click);
            // 
            // Gridview1
            // 
            this.Gridview1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Gridview1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Gridview1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gridview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gridview1.Location = new System.Drawing.Point(249, 490);
            this.Gridview1.Name = "Gridview1";
            this.Gridview1.RowHeadersWidth = 51;
            this.Gridview1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Gridview1.Size = new System.Drawing.Size(1520, 207);
            this.Gridview1.TabIndex = 0;
            this.Gridview1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gridview1_CellClick);
            this.Gridview1.CellContextMenuStripChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gridview1_CellContextMenuStripChanged);
            // 
            // txt_MaLop
            // 
            this.txt_MaLop.Enabled = false;
            this.txt_MaLop.Location = new System.Drawing.Point(1356, 302);
            this.txt_MaLop.Margin = new System.Windows.Forms.Padding(4);
            this.txt_MaLop.Name = "txt_MaLop";
            this.txt_MaLop.Size = new System.Drawing.Size(161, 22);
            this.txt_MaLop.TabIndex = 52;
            // 
            // lbl_MaLop
            // 
            this.lbl_MaLop.AutoSize = true;
            this.lbl_MaLop.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_MaLop.Location = new System.Drawing.Point(1285, 304);
            this.lbl_MaLop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_MaLop.Name = "lbl_MaLop";
            this.lbl_MaLop.Size = new System.Drawing.Size(54, 16);
            this.lbl_MaLop.TabIndex = 51;
            this.lbl_MaLop.Text = "Mã lớp :";
            // 
            // cbb_TrinhDo
            // 
            this.cbb_TrinhDo.FormattingEnabled = true;
            this.cbb_TrinhDo.Items.AddRange(new object[] {
            "12/12",
            "11/12",
            "10/12"});
            this.cbb_TrinhDo.Location = new System.Drawing.Point(1009, 297);
            this.cbb_TrinhDo.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_TrinhDo.Name = "cbb_TrinhDo";
            this.cbb_TrinhDo.Size = new System.Drawing.Size(213, 24);
            this.cbb_TrinhDo.TabIndex = 48;
            this.cbb_TrinhDo.SelectedIndexChanged += new System.EventHandler(this.cbb_TrinhDo_SelectedIndexChanged);
            // 
            // lbl_TrinhDo
            // 
            this.lbl_TrinhDo.AutoSize = true;
            this.lbl_TrinhDo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_TrinhDo.Location = new System.Drawing.Point(903, 300);
            this.lbl_TrinhDo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TrinhDo.Name = "lbl_TrinhDo";
            this.lbl_TrinhDo.Size = new System.Drawing.Size(62, 16);
            this.lbl_TrinhDo.TabIndex = 47;
            this.lbl_TrinhDo.Text = "Trình độ :";
            // 
            // txt_SDT
            // 
            this.txt_SDT.Location = new System.Drawing.Point(1370, 262);
            this.txt_SDT.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SDT.Name = "txt_SDT";
            this.txt_SDT.Size = new System.Drawing.Size(161, 22);
            this.txt_SDT.TabIndex = 46;
            // 
            // lbl_SDT
            // 
            this.lbl_SDT.AutoSize = true;
            this.lbl_SDT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_SDT.Location = new System.Drawing.Point(1285, 265);
            this.lbl_SDT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_SDT.Name = "lbl_SDT";
            this.lbl_SDT.Size = new System.Drawing.Size(91, 16);
            this.lbl_SDT.TabIndex = 45;
            this.lbl_SDT.Text = "Số điện thoại :";
            // 
            // txt_CMND
            // 
            this.txt_CMND.Location = new System.Drawing.Point(1009, 255);
            this.txt_CMND.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CMND.Name = "txt_CMND";
            this.txt_CMND.Size = new System.Drawing.Size(148, 22);
            this.txt_CMND.TabIndex = 44;
            // 
            // lbl_CMND
            // 
            this.lbl_CMND.AutoSize = true;
            this.lbl_CMND.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_CMND.Location = new System.Drawing.Point(902, 258);
            this.lbl_CMND.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CMND.Name = "lbl_CMND";
            this.lbl_CMND.Size = new System.Drawing.Size(73, 16);
            this.lbl_CMND.TabIndex = 43;
            this.lbl_CMND.Text = "Số CMND :";
            // 
            // txt_LuongCB
            // 
            this.txt_LuongCB.Location = new System.Drawing.Point(1385, 345);
            this.txt_LuongCB.Margin = new System.Windows.Forms.Padding(4);
            this.txt_LuongCB.Name = "txt_LuongCB";
            this.txt_LuongCB.Size = new System.Drawing.Size(160, 22);
            this.txt_LuongCB.TabIndex = 42;
            // 
            // lbl_LuongCB
            // 
            this.lbl_LuongCB.AutoSize = true;
            this.lbl_LuongCB.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_LuongCB.Location = new System.Drawing.Point(1283, 343);
            this.lbl_LuongCB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_LuongCB.Name = "lbl_LuongCB";
            this.lbl_LuongCB.Size = new System.Drawing.Size(94, 16);
            this.lbl_LuongCB.TabIndex = 41;
            this.lbl_LuongCB.Text = "Lương cơ bản :";
            // 
            // txt_HSL
            // 
            this.txt_HSL.Location = new System.Drawing.Point(1009, 340);
            this.txt_HSL.Margin = new System.Windows.Forms.Padding(4);
            this.txt_HSL.Name = "txt_HSL";
            this.txt_HSL.Size = new System.Drawing.Size(148, 22);
            this.txt_HSL.TabIndex = 40;
            this.txt_HSL.TextChanged += new System.EventHandler(this.txt_HSL_TextChanged);
            // 
            // lbl_HSL
            // 
            this.lbl_HSL.AutoSize = true;
            this.lbl_HSL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_HSL.Location = new System.Drawing.Point(903, 342);
            this.lbl_HSL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_HSL.Name = "lbl_HSL";
            this.lbl_HSL.Size = new System.Drawing.Size(85, 16);
            this.lbl_HSL.TabIndex = 39;
            this.lbl_HSL.Text = "Hệ số lương :";
            this.lbl_HSL.Click += new System.EventHandler(this.lbl_HSL_Click);
            // 
            // txt_DiaChi
            // 
            this.txt_DiaChi.Location = new System.Drawing.Point(427, 392);
            this.txt_DiaChi.Margin = new System.Windows.Forms.Padding(4);
            this.txt_DiaChi.Multiline = true;
            this.txt_DiaChi.Name = "txt_DiaChi";
            this.txt_DiaChi.Size = new System.Drawing.Size(318, 66);
            this.txt_DiaChi.TabIndex = 38;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(337, 419);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 16);
            this.label5.TabIndex = 37;
            this.label5.Text = "Địa chỉ :";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txt_GT
            // 
            this.txt_GT.Location = new System.Drawing.Point(638, 292);
            this.txt_GT.Name = "txt_GT";
            this.txt_GT.Size = new System.Drawing.Size(107, 22);
            this.txt_GT.TabIndex = 36;
            // 
            // dtp_NgayVaoLam
            // 
            this.dtp_NgayVaoLam.CustomFormat = "dd/MM/yyyy";
            this.dtp_NgayVaoLam.Font = new System.Drawing.Font("Tw Cen MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_NgayVaoLam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_NgayVaoLam.Location = new System.Drawing.Point(697, 341);
            this.dtp_NgayVaoLam.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_NgayVaoLam.Name = "dtp_NgayVaoLam";
            this.dtp_NgayVaoLam.Size = new System.Drawing.Size(148, 29);
            this.dtp_NgayVaoLam.TabIndex = 35;
            // 
            // lbl_NgayVaoLam
            // 
            this.lbl_NgayVaoLam.AutoSize = true;
            this.lbl_NgayVaoLam.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_NgayVaoLam.Location = new System.Drawing.Point(592, 347);
            this.lbl_NgayVaoLam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_NgayVaoLam.Name = "lbl_NgayVaoLam";
            this.lbl_NgayVaoLam.Size = new System.Drawing.Size(97, 16);
            this.lbl_NgayVaoLam.TabIndex = 33;
            this.lbl_NgayVaoLam.Text = "Ngày vào làm :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(562, 295);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Giới tính :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(337, 347);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 29;
            this.label3.Text = "Ngày sinh";
            // 
            // txt_NgayThangNam
            // 
            this.txt_NgayThangNam.CustomFormat = "dd/MM/yyyy";
            this.txt_NgayThangNam.Font = new System.Drawing.Font("Tw Cen MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NgayThangNam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_NgayThangNam.Location = new System.Drawing.Point(427, 340);
            this.txt_NgayThangNam.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NgayThangNam.Name = "txt_NgayThangNam";
            this.txt_NgayThangNam.Size = new System.Drawing.Size(148, 29);
            this.txt_NgayThangNam.TabIndex = 28;
            // 
            // txt_TenGV
            // 
            this.txt_TenGV.Location = new System.Drawing.Point(427, 292);
            this.txt_TenGV.Name = "txt_TenGV";
            this.txt_TenGV.Size = new System.Drawing.Size(107, 22);
            this.txt_TenGV.TabIndex = 7;
            this.txt_TenGV.TextChanged += new System.EventHandler(this.txt_TenKhoi_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(336, 295);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Tên giáo viên";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txt_MaGV
            // 
            this.txt_MaGV.Enabled = false;
            this.txt_MaGV.Location = new System.Drawing.Point(427, 251);
            this.txt_MaGV.Name = "txt_MaGV";
            this.txt_MaGV.Size = new System.Drawing.Size(318, 22);
            this.txt_MaGV.TabIndex = 5;
            this.txt_MaGV.TextChanged += new System.EventHandler(this.txt_MaKhoi_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(337, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã giáo viên";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // ThemGiaoVien_News_
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 785);
            this.Controls.Add(this.grp_KhoiHoc);
            this.Name = "ThemGiaoVien_News_";
            this.Text = "ThemGiaoVien_News: 52000887 + 52000883";
            this.Load += new System.EventHandler(this.ThemGiaoVien_News__Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ThemGiaoVien_News__Paint);
            this.grp_KhoiHoc.ResumeLayout(false);
            this.grp_KhoiHoc.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).EndInit();
            this.ts_ChucNang.ResumeLayout(false);
            this.ts_ChucNang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_KhoiHoc;
        private System.Windows.Forms.TextBox txt_TenGV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_MaGV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView Gridview1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker txt_NgayThangNam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtp_NgayVaoLam;
        private System.Windows.Forms.Label lbl_NgayVaoLam;
        private System.Windows.Forms.TextBox txt_GT;
        private System.Windows.Forms.TextBox txt_DiaChi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_MaLop;
        private System.Windows.Forms.Label lbl_MaLop;
        private System.Windows.Forms.ComboBox cbb_TrinhDo;
        private System.Windows.Forms.Label lbl_TrinhDo;
        private System.Windows.Forms.TextBox txt_SDT;
        private System.Windows.Forms.Label lbl_SDT;
        private System.Windows.Forms.TextBox txt_CMND;
        private System.Windows.Forms.Label lbl_CMND;
        private System.Windows.Forms.Label lbl_LuongCB;
        private System.Windows.Forms.TextBox txt_HSL;
        private System.Windows.Forms.Label lbl_HSL;
        private System.Windows.Forms.TextBox txt_LuongCB;
        private System.Windows.Forms.ToolStrip ts_ChucNang;
        private System.Windows.Forms.ToolStripButton bt_Them;
        private System.Windows.Forms.ToolStripButton bt_Xóa;
        private System.Windows.Forms.ToolStripButton bt_Sửa;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox imgBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_ChonAnh;
    }
}