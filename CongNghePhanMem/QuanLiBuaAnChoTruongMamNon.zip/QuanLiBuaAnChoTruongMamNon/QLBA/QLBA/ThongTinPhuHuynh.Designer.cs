﻿namespace QLBA
{
    partial class ThongTinPhuHuynh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinPhuHuynh));
            this.grp_TTPH = new System.Windows.Forms.GroupBox();
            this.txt_Ma = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_NgheNghiepMe = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_SDTMe = new System.Windows.Forms.TextBox();
            this.txt_HoTenMe = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_NgheNghiepCha = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_SDTCha = new System.Windows.Forms.TextBox();
            this.txt_HoTenCha = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ts_ChucNang = new System.Windows.Forms.ToolStrip();
            this.bt_Them = new System.Windows.Forms.ToolStripButton();
            this.bt_Xóa = new System.Windows.Forms.ToolStripButton();
            this.bt_Sửa = new System.Windows.Forms.ToolStripButton();
            this.Gridview1 = new System.Windows.Forms.DataGridView();
            this.grp_TTPH.SuspendLayout();
            this.ts_ChucNang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).BeginInit();
            this.SuspendLayout();
            // 
            // grp_TTPH
            // 
            this.grp_TTPH.Controls.Add(this.txt_Ma);
            this.grp_TTPH.Controls.Add(this.label7);
            this.grp_TTPH.Controls.Add(this.txt_NgheNghiepMe);
            this.grp_TTPH.Controls.Add(this.label9);
            this.grp_TTPH.Controls.Add(this.txt_SDTMe);
            this.grp_TTPH.Controls.Add(this.txt_HoTenMe);
            this.grp_TTPH.Controls.Add(this.label11);
            this.grp_TTPH.Controls.Add(this.label12);
            this.grp_TTPH.Controls.Add(this.txt_NgheNghiepCha);
            this.grp_TTPH.Controls.Add(this.label10);
            this.grp_TTPH.Controls.Add(this.txt_SDTCha);
            this.grp_TTPH.Controls.Add(this.txt_HoTenCha);
            this.grp_TTPH.Controls.Add(this.label15);
            this.grp_TTPH.Controls.Add(this.label16);
            this.grp_TTPH.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_TTPH.ForeColor = System.Drawing.Color.Blue;
            this.grp_TTPH.Location = new System.Drawing.Point(217, 13);
            this.grp_TTPH.Margin = new System.Windows.Forms.Padding(4);
            this.grp_TTPH.Name = "grp_TTPH";
            this.grp_TTPH.Padding = new System.Windows.Forms.Padding(4);
            this.grp_TTPH.Size = new System.Drawing.Size(1345, 215);
            this.grp_TTPH.TabIndex = 10;
            this.grp_TTPH.TabStop = false;
            this.grp_TTPH.Text = "Thông tin phụ huynh";
            this.grp_TTPH.Paint += new System.Windows.Forms.PaintEventHandler(this.grp_TTPH_Paint);
            // 
            // txt_Ma
            // 
            this.txt_Ma.Enabled = false;
            this.txt_Ma.Location = new System.Drawing.Point(486, 114);
            this.txt_Ma.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Ma.Name = "txt_Ma";
            this.txt_Ma.Size = new System.Drawing.Size(151, 30);
            this.txt_Ma.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(371, 118);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 22);
            this.label7.TabIndex = 21;
            this.label7.Text = "Mã trẻ :";
            // 
            // txt_NgheNghiepMe
            // 
            this.txt_NgheNghiepMe.Location = new System.Drawing.Point(866, 67);
            this.txt_NgheNghiepMe.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NgheNghiepMe.Name = "txt_NgheNghiepMe";
            this.txt_NgheNghiepMe.Size = new System.Drawing.Size(405, 30);
            this.txt_NgheNghiepMe.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(702, 71);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(147, 22);
            this.label9.TabIndex = 19;
            this.label9.Text = "Nghề nghiệp mẹ :";
            // 
            // txt_SDTMe
            // 
            this.txt_SDTMe.Location = new System.Drawing.Point(837, 106);
            this.txt_SDTMe.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SDTMe.Name = "txt_SDTMe";
            this.txt_SDTMe.Size = new System.Drawing.Size(143, 30);
            this.txt_SDTMe.TabIndex = 18;
            // 
            // txt_HoTenMe
            // 
            this.txt_HoTenMe.Location = new System.Drawing.Point(817, 28);
            this.txt_HoTenMe.Margin = new System.Windows.Forms.Padding(4);
            this.txt_HoTenMe.Name = "txt_HoTenMe";
            this.txt_HoTenMe.Size = new System.Drawing.Size(455, 30);
            this.txt_HoTenMe.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(702, 110);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(118, 22);
            this.label11.TabIndex = 16;
            this.label11.Text = "SĐT của mẹ :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(701, 31);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 22);
            this.label12.TabIndex = 15;
            this.label12.Text = "Họ tên mẹ :";
            // 
            // txt_NgheNghiepCha
            // 
            this.txt_NgheNghiepCha.Location = new System.Drawing.Point(220, 70);
            this.txt_NgheNghiepCha.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NgheNghiepCha.Name = "txt_NgheNghiepCha";
            this.txt_NgheNghiepCha.Size = new System.Drawing.Size(405, 30);
            this.txt_NgheNghiepCha.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(56, 74);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(151, 22);
            this.label10.TabIndex = 13;
            this.label10.Text = "Nghề nghiệp cha :";
            // 
            // txt_SDTCha
            // 
            this.txt_SDTCha.Location = new System.Drawing.Point(191, 110);
            this.txt_SDTCha.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SDTCha.Name = "txt_SDTCha";
            this.txt_SDTCha.Size = new System.Drawing.Size(143, 30);
            this.txt_SDTCha.TabIndex = 3;
            // 
            // txt_HoTenCha
            // 
            this.txt_HoTenCha.Location = new System.Drawing.Point(171, 31);
            this.txt_HoTenCha.Margin = new System.Windows.Forms.Padding(4);
            this.txt_HoTenCha.Name = "txt_HoTenCha";
            this.txt_HoTenCha.Size = new System.Drawing.Size(455, 30);
            this.txt_HoTenCha.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(56, 114);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 22);
            this.label15.TabIndex = 1;
            this.label15.Text = "SĐT của cha :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(55, 35);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 22);
            this.label16.TabIndex = 0;
            this.label16.Text = "Họ tên cha :";
            // 
            // ts_ChucNang
            // 
            this.ts_ChucNang.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ts_ChucNang.AutoSize = false;
            this.ts_ChucNang.BackColor = System.Drawing.Color.Honeydew;
            this.ts_ChucNang.Dock = System.Windows.Forms.DockStyle.None;
            this.ts_ChucNang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ts_ChucNang.GripMargin = new System.Windows.Forms.Padding(4);
            this.ts_ChucNang.ImageScalingSize = new System.Drawing.Size(100, 100);
            this.ts_ChucNang.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ts_ChucNang.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bt_Them,
            this.bt_Xóa,
            this.bt_Sửa});
            this.ts_ChucNang.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.ts_ChucNang.Location = new System.Drawing.Point(17, 9);
            this.ts_ChucNang.Name = "ts_ChucNang";
            this.ts_ChucNang.Size = new System.Drawing.Size(168, 474);
            this.ts_ChucNang.TabIndex = 54;
            // 
            // bt_Them
            // 
            this.bt_Them.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Them.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bt_Them.Image = ((System.Drawing.Image)(resources.GetObject("bt_Them.Image")));
            this.bt_Them.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bt_Them.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bt_Them.Name = "bt_Them";
            this.bt_Them.Size = new System.Drawing.Size(104, 127);
            this.bt_Them.Text = "Thêm";
            this.bt_Them.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Them.Click += new System.EventHandler(this.bt_Them_Click);
            // 
            // bt_Xóa
            // 
            this.bt_Xóa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Xóa.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bt_Xóa.Image = ((System.Drawing.Image)(resources.GetObject("bt_Xóa.Image")));
            this.bt_Xóa.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.bt_Xóa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bt_Xóa.Name = "bt_Xóa";
            this.bt_Xóa.Size = new System.Drawing.Size(104, 127);
            this.bt_Xóa.Text = "Xóa";
            this.bt_Xóa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Xóa.Click += new System.EventHandler(this.bt_Xóa_Click);
            // 
            // bt_Sửa
            // 
            this.bt_Sửa.BackColor = System.Drawing.Color.Honeydew;
            this.bt_Sửa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Sửa.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bt_Sửa.Image = ((System.Drawing.Image)(resources.GetObject("bt_Sửa.Image")));
            this.bt_Sửa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bt_Sửa.Name = "bt_Sửa";
            this.bt_Sửa.Size = new System.Drawing.Size(104, 127);
            this.bt_Sửa.Text = "Sửa";
            this.bt_Sửa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Sửa.Click += new System.EventHandler(this.bt_Sửa_Click);
            // 
            // Gridview1
            // 
            this.Gridview1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Gridview1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Gridview1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gridview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gridview1.Location = new System.Drawing.Point(210, 255);
            this.Gridview1.Name = "Gridview1";
            this.Gridview1.RowHeadersWidth = 51;
            this.Gridview1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Gridview1.Size = new System.Drawing.Size(1352, 302);
            this.Gridview1.TabIndex = 55;
            this.Gridview1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gridview1_CellClick);
            // 
            // ThongTinPhuHuynh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1628, 569);
            this.Controls.Add(this.Gridview1);
            this.Controls.Add(this.ts_ChucNang);
            this.Controls.Add(this.grp_TTPH);
            this.Name = "ThongTinPhuHuynh";
            this.Text = "ThongTinPhuHuynh: 52000887 + 52000883";
            this.Load += new System.EventHandler(this.ThongTinPhuHuynh_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ThongTinPhuHuynh_Paint);
            this.grp_TTPH.ResumeLayout(false);
            this.grp_TTPH.PerformLayout();
            this.ts_ChucNang.ResumeLayout(false);
            this.ts_ChucNang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_TTPH;
        private System.Windows.Forms.TextBox txt_NgheNghiepMe;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_SDTMe;
        private System.Windows.Forms.TextBox txt_HoTenMe;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_NgheNghiepCha;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_SDTCha;
        private System.Windows.Forms.TextBox txt_HoTenCha;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ToolStrip ts_ChucNang;
        private System.Windows.Forms.ToolStripButton bt_Them;
        private System.Windows.Forms.ToolStripButton bt_Xóa;
        private System.Windows.Forms.ToolStripButton bt_Sửa;
        private System.Windows.Forms.DataGridView Gridview1;
        private System.Windows.Forms.TextBox txt_Ma;
        private System.Windows.Forms.Label label7;
    }
}