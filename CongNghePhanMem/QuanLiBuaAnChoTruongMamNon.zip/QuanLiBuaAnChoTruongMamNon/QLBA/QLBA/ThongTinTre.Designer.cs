﻿namespace QLBA
{
    partial class ThongTinTre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinTre));
            this.tab_ThongTinTre = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Gridview1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.imgBox = new System.Windows.Forms.PictureBox();
            this.bt_Them = new System.Windows.Forms.Button();
            this.bt_CapNhat = new System.Windows.Forms.Button();
            this.bt_Xoa = new System.Windows.Forms.Button();
            this.grp_TTHS = new System.Windows.Forms.GroupBox();
            this.txt_GT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NgayThangNam = new System.Windows.Forms.DateTimePicker();
            this.txt_Ma = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_NgayNhapHoc = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_LopHienTai = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_DiaChi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_HoTen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.tab_XepLop = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.grp_LopHienTai = new System.Windows.Forms.GroupBox();
            this.cbb_LopHienTai = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lst_LopHienTai = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.grp_LopMoi = new System.Windows.Forms.GroupBox();
            this.lst_LopMoi = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbb_LopMoi = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.bt_UpAll = new System.Windows.Forms.Button();
            this.bt_Up = new System.Windows.Forms.Button();
            this.bt_Down = new System.Windows.Forms.Button();
            this.bt_Luu = new System.Windows.Forms.Button();
            this.bt_DownAll = new System.Windows.Forms.Button();
            this.tab_HocPhi = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.bt_Update = new System.Windows.Forms.Button();
            this.ck_CapNhat = new System.Windows.Forms.CheckBox();
            this.bt_SetHP = new System.Windows.Forms.Button();
            this.txt_SoTien = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.bt_HienThi = new System.Windows.Forms.Button();
            this.cbb_Nam = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cbb_Thang = new System.Windows.Forms.ComboBox();
            this.cbb_LopHoc = new System.Windows.Forms.ComboBox();
            this.dgV_HocPhi = new System.Windows.Forms.DataGridView();
            this.col_MaTre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TenTre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TenLop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ThangNam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_HocPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_TinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_checkHP = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.col_NgayThu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.grp_DSLH = new System.Windows.Forms.GroupBox();
            this.tab_ThongTinTre.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).BeginInit();
            this.grp_TTHS.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tab_XepLop.SuspendLayout();
            this.panel3.SuspendLayout();
            this.grp_LopHienTai.SuspendLayout();
            this.grp_LopMoi.SuspendLayout();
            this.tab_HocPhi.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgV_HocPhi)).BeginInit();
            this.SuspendLayout();
            // 
            // tab_ThongTinTre
            // 
            this.tab_ThongTinTre.Controls.Add(this.tabPage1);
            this.tab_ThongTinTre.Controls.Add(this.tab_XepLop);
            this.tab_ThongTinTre.Controls.Add(this.tab_HocPhi);
            this.tab_ThongTinTre.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_ThongTinTre.Location = new System.Drawing.Point(13, 13);
            this.tab_ThongTinTre.Margin = new System.Windows.Forms.Padding(4);
            this.tab_ThongTinTre.Name = "tab_ThongTinTre";
            this.tab_ThongTinTre.SelectedIndex = 0;
            this.tab_ThongTinTre.Size = new System.Drawing.Size(1915, 1040);
            this.tab_ThongTinTre.TabIndex = 1;
            this.tab_ThongTinTre.SelectedIndexChanged += new System.EventHandler(this.tab_ThongTinTre_SelectedIndexChanged);
            this.tab_ThongTinTre.TabIndexChanged += new System.EventHandler(this.tab_ThongTinTre_TabIndexChanged);
            this.tab_ThongTinTre.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Menu;
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1907, 1005);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Thông tin trẻ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.Gridview1);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.imgBox);
            this.panel2.Controls.Add(this.bt_Them);
            this.panel2.Controls.Add(this.bt_CapNhat);
            this.panel2.Controls.Add(this.bt_Xoa);
            this.panel2.Controls.Add(this.grp_TTHS);
            this.panel2.Location = new System.Drawing.Point(0, 131);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1678, 867);
            this.panel2.TabIndex = 33;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Gridview1
            // 
            this.Gridview1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Gridview1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Gridview1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gridview1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gridview1.Location = new System.Drawing.Point(204, 244);
            this.Gridview1.Name = "Gridview1";
            this.Gridview1.RowHeadersWidth = 51;
            this.Gridview1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Gridview1.Size = new System.Drawing.Size(1470, 302);
            this.Gridview1.TabIndex = 12;
            this.Gridview1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gridview1_CellClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 200);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 34);
            this.button1.TabIndex = 11;
            this.button1.Text = "Chọn ảnh...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // imgBox
            // 
            this.imgBox.Location = new System.Drawing.Point(0, 0);
            this.imgBox.Margin = new System.Windows.Forms.Padding(4);
            this.imgBox.Name = "imgBox";
            this.imgBox.Size = new System.Drawing.Size(196, 201);
            this.imgBox.TabIndex = 10;
            this.imgBox.TabStop = false;
            // 
            // bt_Them
            // 
            this.bt_Them.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Them.BackgroundImage")));
            this.bt_Them.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bt_Them.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_Them.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Them.Location = new System.Drawing.Point(20, 236);
            this.bt_Them.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Them.Name = "bt_Them";
            this.bt_Them.Size = new System.Drawing.Size(155, 98);
            this.bt_Them.TabIndex = 3;
            this.bt_Them.Text = " ";
            this.bt_Them.UseVisualStyleBackColor = true;
            this.bt_Them.Click += new System.EventHandler(this.bt_Them_Click_1);
            // 
            // bt_CapNhat
            // 
            this.bt_CapNhat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_CapNhat.BackgroundImage")));
            this.bt_CapNhat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bt_CapNhat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_CapNhat.Location = new System.Drawing.Point(20, 448);
            this.bt_CapNhat.Margin = new System.Windows.Forms.Padding(4);
            this.bt_CapNhat.Name = "bt_CapNhat";
            this.bt_CapNhat.Size = new System.Drawing.Size(155, 98);
            this.bt_CapNhat.TabIndex = 4;
            this.bt_CapNhat.UseVisualStyleBackColor = true;
            this.bt_CapNhat.Click += new System.EventHandler(this.bt_CapNhat_Click);
            // 
            // bt_Xoa
            // 
            this.bt_Xoa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Xoa.BackgroundImage")));
            this.bt_Xoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bt_Xoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_Xoa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Xoa.Location = new System.Drawing.Point(20, 342);
            this.bt_Xoa.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Xoa.Name = "bt_Xoa";
            this.bt_Xoa.Size = new System.Drawing.Size(155, 98);
            this.bt_Xoa.TabIndex = 5;
            this.bt_Xoa.UseVisualStyleBackColor = true;
            this.bt_Xoa.Click += new System.EventHandler(this.bt_Xoa_Click);
            // 
            // grp_TTHS
            // 
            this.grp_TTHS.BackColor = System.Drawing.Color.Transparent;
            this.grp_TTHS.Controls.Add(this.txt_GT);
            this.grp_TTHS.Controls.Add(this.label3);
            this.grp_TTHS.Controls.Add(this.txt_NgayThangNam);
            this.grp_TTHS.Controls.Add(this.txt_Ma);
            this.grp_TTHS.Controls.Add(this.label7);
            this.grp_TTHS.Controls.Add(this.txt_NgayNhapHoc);
            this.grp_TTHS.Controls.Add(this.label6);
            this.grp_TTHS.Controls.Add(this.txt_LopHienTai);
            this.grp_TTHS.Controls.Add(this.label5);
            this.grp_TTHS.Controls.Add(this.txt_DiaChi);
            this.grp_TTHS.Controls.Add(this.label4);
            this.grp_TTHS.Controls.Add(this.txt_HoTen);
            this.grp_TTHS.Controls.Add(this.label2);
            this.grp_TTHS.Controls.Add(this.label1);
            this.grp_TTHS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_TTHS.ForeColor = System.Drawing.Color.Blue;
            this.grp_TTHS.Location = new System.Drawing.Point(204, 5);
            this.grp_TTHS.Margin = new System.Windows.Forms.Padding(4);
            this.grp_TTHS.Name = "grp_TTHS";
            this.grp_TTHS.Padding = new System.Windows.Forms.Padding(4);
            this.grp_TTHS.Size = new System.Drawing.Size(1470, 196);
            this.grp_TTHS.TabIndex = 8;
            this.grp_TTHS.TabStop = false;
            this.grp_TTHS.Text = "Thông tin học sinh";
            this.grp_TTHS.Enter += new System.EventHandler(this.grp_TTHS_Enter);
            // 
            // txt_GT
            // 
            this.txt_GT.Location = new System.Drawing.Point(431, 70);
            this.txt_GT.Name = "txt_GT";
            this.txt_GT.Size = new System.Drawing.Size(117, 30);
            this.txt_GT.TabIndex = 38;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(321, 73);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 22);
            this.label3.TabIndex = 37;
            this.label3.Text = "Giới tính :";
            // 
            // txt_NgayThangNam
            // 
            this.txt_NgayThangNam.CustomFormat = "dd/MM/yyyy";
            this.txt_NgayThangNam.Font = new System.Drawing.Font("Tw Cen MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NgayThangNam.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txt_NgayThangNam.Location = new System.Drawing.Point(147, 106);
            this.txt_NgayThangNam.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NgayThangNam.Name = "txt_NgayThangNam";
            this.txt_NgayThangNam.Size = new System.Drawing.Size(151, 29);
            this.txt_NgayThangNam.TabIndex = 17;
            // 
            // txt_Ma
            // 
            this.txt_Ma.Enabled = false;
            this.txt_Ma.Location = new System.Drawing.Point(147, 66);
            this.txt_Ma.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Ma.Name = "txt_Ma";
            this.txt_Ma.Size = new System.Drawing.Size(151, 30);
            this.txt_Ma.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(32, 70);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 22);
            this.label7.TabIndex = 13;
            this.label7.Text = "Mã trẻ :";
            // 
            // txt_NgayNhapHoc
            // 
            this.txt_NgayNhapHoc.Enabled = false;
            this.txt_NgayNhapHoc.Location = new System.Drawing.Point(459, 106);
            this.txt_NgayNhapHoc.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NgayNhapHoc.Name = "txt_NgayNhapHoc";
            this.txt_NgayNhapHoc.Size = new System.Drawing.Size(143, 30);
            this.txt_NgayNhapHoc.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(316, 110);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "Ngày nhập học :";
            // 
            // txt_LopHienTai
            // 
            this.txt_LopHienTai.Enabled = false;
            this.txt_LopHienTai.Location = new System.Drawing.Point(737, 31);
            this.txt_LopHienTai.Margin = new System.Windows.Forms.Padding(4);
            this.txt_LopHienTai.Name = "txt_LopHienTai";
            this.txt_LopHienTai.Size = new System.Drawing.Size(316, 30);
            this.txt_LopHienTai.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(622, 35);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 22);
            this.label5.TabIndex = 9;
            this.label5.Text = "Lớp hiện tại :";
            // 
            // txt_DiaChi
            // 
            this.txt_DiaChi.Location = new System.Drawing.Point(737, 102);
            this.txt_DiaChi.Margin = new System.Windows.Forms.Padding(4);
            this.txt_DiaChi.Multiline = true;
            this.txt_DiaChi.Name = "txt_DiaChi";
            this.txt_DiaChi.Size = new System.Drawing.Size(455, 66);
            this.txt_DiaChi.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(622, 106);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "Địa chỉ :";
            // 
            // txt_HoTen
            // 
            this.txt_HoTen.Location = new System.Drawing.Point(147, 27);
            this.txt_HoTen.Margin = new System.Windows.Forms.Padding(4);
            this.txt_HoTen.Name = "txt_HoTen";
            this.txt_HoTen.Size = new System.Drawing.Size(455, 30);
            this.txt_HoTen.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(32, 110);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày sinh :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(31, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ tên trẻ :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.label13);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(261, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1201, 123);
            this.panel1.TabIndex = 32;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label13.Location = new System.Drawing.Point(295, 16);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(588, 90);
            this.label13.TabIndex = 0;
            this.label13.Text = "QUẢN LÝ TRẺ";
            // 
            // tab_XepLop
            // 
            this.tab_XepLop.BackColor = System.Drawing.SystemColors.Control;
            this.tab_XepLop.Controls.Add(this.panel3);
            this.tab_XepLop.Location = new System.Drawing.Point(4, 31);
            this.tab_XepLop.Margin = new System.Windows.Forms.Padding(4);
            this.tab_XepLop.Name = "tab_XepLop";
            this.tab_XepLop.Padding = new System.Windows.Forms.Padding(4);
            this.tab_XepLop.Size = new System.Drawing.Size(1907, 1005);
            this.tab_XepLop.TabIndex = 1;
            this.tab_XepLop.Text = "Xếp lớp";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.grp_LopHienTai);
            this.panel3.Controls.Add(this.grp_LopMoi);
            this.panel3.Controls.Add(this.bt_UpAll);
            this.panel3.Controls.Add(this.bt_Up);
            this.panel3.Controls.Add(this.bt_Down);
            this.panel3.Controls.Add(this.bt_Luu);
            this.panel3.Controls.Add(this.bt_DownAll);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1208, 712);
            this.panel3.TabIndex = 14;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // grp_LopHienTai
            // 
            this.grp_LopHienTai.BackColor = System.Drawing.Color.Transparent;
            this.grp_LopHienTai.Controls.Add(this.cbb_LopHienTai);
            this.grp_LopHienTai.Controls.Add(this.label14);
            this.grp_LopHienTai.Controls.Add(this.lst_LopHienTai);
            this.grp_LopHienTai.Location = new System.Drawing.Point(11, 0);
            this.grp_LopHienTai.Margin = new System.Windows.Forms.Padding(4);
            this.grp_LopHienTai.Name = "grp_LopHienTai";
            this.grp_LopHienTai.Padding = new System.Windows.Forms.Padding(4);
            this.grp_LopHienTai.Size = new System.Drawing.Size(1187, 297);
            this.grp_LopHienTai.TabIndex = 0;
            this.grp_LopHienTai.TabStop = false;
            // 
            // cbb_LopHienTai
            // 
            this.cbb_LopHienTai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_LopHienTai.FormattingEnabled = true;
            this.cbb_LopHienTai.Location = new System.Drawing.Point(623, 25);
            this.cbb_LopHienTai.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_LopHienTai.Name = "cbb_LopHienTai";
            this.cbb_LopHienTai.Size = new System.Drawing.Size(160, 30);
            this.cbb_LopHienTai.TabIndex = 13;
            this.cbb_LopHienTai.SelectedIndexChanged += new System.EventHandler(this.cbb_LopHienTai_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(444, 26);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(154, 22);
            this.label14.TabIndex = 11;
            this.label14.Text = "Lớp học hiện tại : ";
            // 
            // lst_LopHienTai
            // 
            this.lst_LopHienTai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.lst_LopHienTai.FullRowSelect = true;
            this.lst_LopHienTai.GridLines = true;
            this.lst_LopHienTai.HideSelection = false;
            this.lst_LopHienTai.Location = new System.Drawing.Point(31, 63);
            this.lst_LopHienTai.Margin = new System.Windows.Forms.Padding(4);
            this.lst_LopHienTai.Name = "lst_LopHienTai";
            this.lst_LopHienTai.Size = new System.Drawing.Size(1125, 221);
            this.lst_LopHienTai.TabIndex = 9;
            this.lst_LopHienTai.UseCompatibleStateImageBehavior = false;
            this.lst_LopHienTai.View = System.Windows.Forms.View.Details;
            this.lst_LopHienTai.SelectedIndexChanged += new System.EventHandler(this.lst_LopHienTai_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã trẻ";
            this.columnHeader1.Width = 108;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên trẻ";
            this.columnHeader2.Width = 233;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Ngày sinh";
            this.columnHeader5.Width = 140;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Giới tính";
            this.columnHeader6.Width = 88;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Ngày nhập học";
            this.columnHeader7.Width = 131;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Mã lớp";
            this.columnHeader8.Width = 139;
            // 
            // grp_LopMoi
            // 
            this.grp_LopMoi.BackColor = System.Drawing.Color.Transparent;
            this.grp_LopMoi.Controls.Add(this.lst_LopMoi);
            this.grp_LopMoi.Controls.Add(this.cbb_LopMoi);
            this.grp_LopMoi.Controls.Add(this.label17);
            this.grp_LopMoi.Location = new System.Drawing.Point(11, 407);
            this.grp_LopMoi.Margin = new System.Windows.Forms.Padding(4);
            this.grp_LopMoi.Name = "grp_LopMoi";
            this.grp_LopMoi.Padding = new System.Windows.Forms.Padding(4);
            this.grp_LopMoi.Size = new System.Drawing.Size(1161, 297);
            this.grp_LopMoi.TabIndex = 5;
            this.grp_LopMoi.TabStop = false;
            // 
            // lst_LopMoi
            // 
            this.lst_LopMoi.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12});
            this.lst_LopMoi.FullRowSelect = true;
            this.lst_LopMoi.GridLines = true;
            this.lst_LopMoi.HideSelection = false;
            this.lst_LopMoi.Location = new System.Drawing.Point(31, 62);
            this.lst_LopMoi.Margin = new System.Windows.Forms.Padding(4);
            this.lst_LopMoi.Name = "lst_LopMoi";
            this.lst_LopMoi.Size = new System.Drawing.Size(1125, 221);
            this.lst_LopMoi.TabIndex = 10;
            this.lst_LopMoi.UseCompatibleStateImageBehavior = false;
            this.lst_LopMoi.View = System.Windows.Forms.View.Details;
            this.lst_LopMoi.SelectedIndexChanged += new System.EventHandler(this.lst_LopMoi_SelectedIndexChanged);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Mã trẻ";
            this.columnHeader3.Width = 108;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Tên trẻ";
            this.columnHeader4.Width = 233;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Ngày sinh";
            this.columnHeader9.Width = 140;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Giới tính";
            this.columnHeader10.Width = 88;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Ngày nhập học";
            this.columnHeader11.Width = 131;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Mã lớp";
            this.columnHeader12.Width = 139;
            // 
            // cbb_LopMoi
            // 
            this.cbb_LopMoi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_LopMoi.FormattingEnabled = true;
            this.cbb_LopMoi.Location = new System.Drawing.Point(623, 21);
            this.cbb_LopMoi.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_LopMoi.Name = "cbb_LopMoi";
            this.cbb_LopMoi.Size = new System.Drawing.Size(160, 30);
            this.cbb_LopMoi.TabIndex = 8;
            this.cbb_LopMoi.SelectedIndexChanged += new System.EventHandler(this.cbb_LopMoi_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(444, 25);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(127, 22);
            this.label17.TabIndex = 6;
            this.label17.Text = "Lớp học mới : ";
            // 
            // bt_UpAll
            // 
            this.bt_UpAll.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_UpAll.BackgroundImage")));
            this.bt_UpAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_UpAll.Location = new System.Drawing.Point(747, 306);
            this.bt_UpAll.Margin = new System.Windows.Forms.Padding(4);
            this.bt_UpAll.Name = "bt_UpAll";
            this.bt_UpAll.Size = new System.Drawing.Size(107, 98);
            this.bt_UpAll.TabIndex = 13;
            this.bt_UpAll.UseVisualStyleBackColor = true;
            this.bt_UpAll.Click += new System.EventHandler(this.bt_UpAll_Click);
            // 
            // bt_Up
            // 
            this.bt_Up.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Up.BackgroundImage")));
            this.bt_Up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Up.Enabled = false;
            this.bt_Up.Location = new System.Drawing.Point(573, 304);
            this.bt_Up.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Up.Name = "bt_Up";
            this.bt_Up.Size = new System.Drawing.Size(107, 98);
            this.bt_Up.TabIndex = 12;
            this.bt_Up.UseVisualStyleBackColor = true;
            this.bt_Up.Click += new System.EventHandler(this.bt_Up_Click);
            // 
            // bt_Down
            // 
            this.bt_Down.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Down.BackgroundImage")));
            this.bt_Down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Down.Enabled = false;
            this.bt_Down.Location = new System.Drawing.Point(239, 306);
            this.bt_Down.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Down.Name = "bt_Down";
            this.bt_Down.Size = new System.Drawing.Size(107, 98);
            this.bt_Down.TabIndex = 9;
            this.bt_Down.UseVisualStyleBackColor = true;
            this.bt_Down.Click += new System.EventHandler(this.bt_Down_Click);
            // 
            // bt_Luu
            // 
            this.bt_Luu.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Luu.ForeColor = System.Drawing.Color.MediumBlue;
            this.bt_Luu.Location = new System.Drawing.Point(1065, 306);
            this.bt_Luu.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Luu.Name = "bt_Luu";
            this.bt_Luu.Size = new System.Drawing.Size(107, 98);
            this.bt_Luu.TabIndex = 10;
            this.bt_Luu.Text = "Lưu";
            this.bt_Luu.UseVisualStyleBackColor = true;
            this.bt_Luu.Click += new System.EventHandler(this.bt_Luu_Click);
            // 
            // bt_DownAll
            // 
            this.bt_DownAll.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_DownAll.BackgroundImage")));
            this.bt_DownAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_DownAll.Location = new System.Drawing.Point(408, 306);
            this.bt_DownAll.Margin = new System.Windows.Forms.Padding(4);
            this.bt_DownAll.Name = "bt_DownAll";
            this.bt_DownAll.Size = new System.Drawing.Size(107, 98);
            this.bt_DownAll.TabIndex = 11;
            this.bt_DownAll.UseVisualStyleBackColor = true;
            this.bt_DownAll.Click += new System.EventHandler(this.bt_DownAll_Click);
            // 
            // tab_HocPhi
            // 
            this.tab_HocPhi.BackColor = System.Drawing.SystemColors.Control;
            this.tab_HocPhi.Controls.Add(this.panel4);
            this.tab_HocPhi.Location = new System.Drawing.Point(4, 31);
            this.tab_HocPhi.Margin = new System.Windows.Forms.Padding(4);
            this.tab_HocPhi.Name = "tab_HocPhi";
            this.tab_HocPhi.Size = new System.Drawing.Size(1907, 1005);
            this.tab_HocPhi.TabIndex = 2;
            this.tab_HocPhi.Text = "Học phí";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.bt_Update);
            this.panel4.Controls.Add(this.ck_CapNhat);
            this.panel4.Controls.Add(this.bt_SetHP);
            this.panel4.Controls.Add(this.txt_SoTien);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.bt_HienThi);
            this.panel4.Controls.Add(this.cbb_Nam);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.cbb_Thang);
            this.panel4.Controls.Add(this.cbb_LopHoc);
            this.panel4.Controls.Add(this.dgV_HocPhi);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Location = new System.Drawing.Point(0, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1200, 725);
            this.panel4.TabIndex = 8;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.MediumBlue;
            this.button2.Location = new System.Drawing.Point(23, 665);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(203, 33);
            this.button2.TabIndex = 16;
            this.button2.Text = "Xem báo cáo học phí";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // bt_Update
            // 
            this.bt_Update.ForeColor = System.Drawing.Color.MediumBlue;
            this.bt_Update.Location = new System.Drawing.Point(1072, 665);
            this.bt_Update.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Update.Name = "bt_Update";
            this.bt_Update.Size = new System.Drawing.Size(100, 33);
            this.bt_Update.TabIndex = 15;
            this.bt_Update.Text = "Cập nhật";
            this.bt_Update.UseVisualStyleBackColor = true;
            this.bt_Update.Click += new System.EventHandler(this.bt_Update_Click_1);
            // 
            // ck_CapNhat
            // 
            this.ck_CapNhat.AutoSize = true;
            this.ck_CapNhat.BackColor = System.Drawing.Color.Transparent;
            this.ck_CapNhat.Enabled = false;
            this.ck_CapNhat.Location = new System.Drawing.Point(676, 114);
            this.ck_CapNhat.Margin = new System.Windows.Forms.Padding(4);
            this.ck_CapNhat.Name = "ck_CapNhat";
            this.ck_CapNhat.Size = new System.Drawing.Size(177, 26);
            this.ck_CapNhat.TabIndex = 14;
            this.ck_CapNhat.Text = "Cho phép cập nhật";
            this.ck_CapNhat.UseVisualStyleBackColor = false;
            this.ck_CapNhat.CheckedChanged += new System.EventHandler(this.ck_CapNhat_CheckedChanged);
            // 
            // bt_SetHP
            // 
            this.bt_SetHP.Enabled = false;
            this.bt_SetHP.Location = new System.Drawing.Point(455, 111);
            this.bt_SetHP.Margin = new System.Windows.Forms.Padding(4);
            this.bt_SetHP.Name = "bt_SetHP";
            this.bt_SetHP.Size = new System.Drawing.Size(100, 33);
            this.bt_SetHP.TabIndex = 13;
            this.bt_SetHP.Text = "Đặt";
            this.bt_SetHP.UseVisualStyleBackColor = true;
            this.bt_SetHP.Click += new System.EventHandler(this.bt_SetHP_Click);
            // 
            // txt_SoTien
            // 
            this.txt_SoTien.Enabled = false;
            this.txt_SoTien.Location = new System.Drawing.Point(252, 112);
            this.txt_SoTien.Margin = new System.Windows.Forms.Padding(4);
            this.txt_SoTien.Name = "txt_SoTien";
            this.txt_SoTien.Size = new System.Drawing.Size(172, 30);
            this.txt_SoTien.TabIndex = 12;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Location = new System.Drawing.Point(17, 116);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(232, 22);
            this.label22.TabIndex = 11;
            this.label22.Text = "Đặt học phí cho danh sách : ";
            // 
            // bt_HienThi
            // 
            this.bt_HienThi.Location = new System.Drawing.Point(668, 59);
            this.bt_HienThi.Margin = new System.Windows.Forms.Padding(4);
            this.bt_HienThi.Name = "bt_HienThi";
            this.bt_HienThi.Size = new System.Drawing.Size(100, 33);
            this.bt_HienThi.TabIndex = 1;
            this.bt_HienThi.Text = "Hiển thị";
            this.bt_HienThi.UseVisualStyleBackColor = true;
            this.bt_HienThi.Click += new System.EventHandler(this.bt_HienThi_Click);
            // 
            // cbb_Nam
            // 
            this.cbb_Nam.FormattingEnabled = true;
            this.cbb_Nam.Location = new System.Drawing.Point(559, 59);
            this.cbb_Nam.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_Nam.Name = "cbb_Nam";
            this.cbb_Nam.Size = new System.Drawing.Size(88, 30);
            this.cbb_Nam.TabIndex = 10;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Location = new System.Drawing.Point(501, 63);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 22);
            this.label21.TabIndex = 9;
            this.label21.Text = "Năm :";
            // 
            // cbb_Thang
            // 
            this.cbb_Thang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_Thang.FormattingEnabled = true;
            this.cbb_Thang.Location = new System.Drawing.Point(412, 59);
            this.cbb_Thang.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_Thang.Name = "cbb_Thang";
            this.cbb_Thang.Size = new System.Drawing.Size(73, 30);
            this.cbb_Thang.TabIndex = 8;
            // 
            // cbb_LopHoc
            // 
            this.cbb_LopHoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_LopHoc.FormattingEnabled = true;
            this.cbb_LopHoc.Location = new System.Drawing.Point(121, 59);
            this.cbb_LopHoc.Margin = new System.Windows.Forms.Padding(4);
            this.cbb_LopHoc.Name = "cbb_LopHoc";
            this.cbb_LopHoc.Size = new System.Drawing.Size(160, 30);
            this.cbb_LopHoc.TabIndex = 6;
            // 
            // dgV_HocPhi
            // 
            this.dgV_HocPhi.AllowUserToAddRows = false;
            this.dgV_HocPhi.AllowUserToDeleteRows = false;
            this.dgV_HocPhi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgV_HocPhi.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgV_HocPhi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgV_HocPhi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_MaTre,
            this.col_TenTre,
            this.col_TenLop,
            this.col_ThangNam,
            this.col_HocPhi,
            this.col_TinhTrang,
            this.col_checkHP,
            this.col_NgayThu});
            this.dgV_HocPhi.Location = new System.Drawing.Point(21, 162);
            this.dgV_HocPhi.Margin = new System.Windows.Forms.Padding(4);
            this.dgV_HocPhi.Name = "dgV_HocPhi";
            this.dgV_HocPhi.RowHeadersWidth = 51;
            this.dgV_HocPhi.Size = new System.Drawing.Size(1118, 462);
            this.dgV_HocPhi.TabIndex = 7;
            this.dgV_HocPhi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgV_HocPhi_CellClick);
            this.dgV_HocPhi.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgV_HocPhi_CellContentClick);
            this.dgV_HocPhi.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgV_HocPhi_CellEndEdit);
            this.dgV_HocPhi.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgV_HocPhi_CurrentCellDirtyStateChanged);
            // 
            // col_MaTre
            // 
            this.col_MaTre.DataPropertyName = "MaTre";
            this.col_MaTre.HeaderText = "Mã trẻ";
            this.col_MaTre.MinimumWidth = 6;
            this.col_MaTre.Name = "col_MaTre";
            this.col_MaTre.ReadOnly = true;
            // 
            // col_TenTre
            // 
            this.col_TenTre.DataPropertyName = "TenTre";
            this.col_TenTre.HeaderText = "Tên trẻ";
            this.col_TenTre.MinimumWidth = 6;
            this.col_TenTre.Name = "col_TenTre";
            this.col_TenTre.ReadOnly = true;
            // 
            // col_TenLop
            // 
            this.col_TenLop.DataPropertyName = "TenLop";
            this.col_TenLop.HeaderText = "Tên lớp";
            this.col_TenLop.MinimumWidth = 6;
            this.col_TenLop.Name = "col_TenLop";
            this.col_TenLop.ReadOnly = true;
            // 
            // col_ThangNam
            // 
            this.col_ThangNam.DataPropertyName = "ThangNam";
            this.col_ThangNam.HeaderText = "Tháng";
            this.col_ThangNam.MinimumWidth = 6;
            this.col_ThangNam.Name = "col_ThangNam";
            this.col_ThangNam.ReadOnly = true;
            // 
            // col_HocPhi
            // 
            this.col_HocPhi.DataPropertyName = "SoTien";
            this.col_HocPhi.HeaderText = "Học phí";
            this.col_HocPhi.MinimumWidth = 6;
            this.col_HocPhi.Name = "col_HocPhi";
            // 
            // col_TinhTrang
            // 
            this.col_TinhTrang.DataPropertyName = "TinhTrang";
            this.col_TinhTrang.HeaderText = "Tình trạng";
            this.col_TinhTrang.MinimumWidth = 6;
            this.col_TinhTrang.Name = "col_TinhTrang";
            // 
            // col_checkHP
            // 
            this.col_checkHP.HeaderText = "Tình trạng";
            this.col_checkHP.MinimumWidth = 6;
            this.col_checkHP.Name = "col_checkHP";
            // 
            // col_NgayThu
            // 
            this.col_NgayThu.DataPropertyName = "NgayThu";
            this.col_NgayThu.HeaderText = "Ngày thu";
            this.col_NgayThu.MinimumWidth = 6;
            this.col_NgayThu.Name = "col_NgayThu";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Location = new System.Drawing.Point(345, 63);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 22);
            this.label18.TabIndex = 1;
            this.label18.Text = "Tháng :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Location = new System.Drawing.Point(17, 63);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 22);
            this.label20.TabIndex = 5;
            this.label20.Text = "Lớp học :";
            // 
            // grp_DSLH
            // 
            this.grp_DSLH.BackColor = System.Drawing.Color.Transparent;
            this.grp_DSLH.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_DSLH.ForeColor = System.Drawing.Color.Blue;
            this.grp_DSLH.Location = new System.Drawing.Point(1344, 68);
            this.grp_DSLH.Margin = new System.Windows.Forms.Padding(4);
            this.grp_DSLH.Name = "grp_DSLH";
            this.grp_DSLH.Padding = new System.Windows.Forms.Padding(4);
            this.grp_DSLH.Size = new System.Drawing.Size(320, 558);
            this.grp_DSLH.TabIndex = 7;
            this.grp_DSLH.TabStop = false;
            this.grp_DSLH.Text = "Danh sách lớp học";
            // 
            // ThongTinTre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 899);
            this.Controls.Add(this.tab_ThongTinTre);
            this.Controls.Add(this.grp_DSLH);
            this.Name = "ThongTinTre";
            this.Text = "ThongTinTre: 52000887 + 52000883";
            this.Load += new System.EventHandler(this.ThongTinTre_Load);
            this.Click += new System.EventHandler(this.button2_Click);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ThongTinTre_Paint);
            this.tab_ThongTinTre.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Gridview1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgBox)).EndInit();
            this.grp_TTHS.ResumeLayout(false);
            this.grp_TTHS.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tab_XepLop.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.grp_LopHienTai.ResumeLayout(false);
            this.grp_LopHienTai.PerformLayout();
            this.grp_LopMoi.ResumeLayout(false);
            this.grp_LopMoi.PerformLayout();
            this.tab_HocPhi.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgV_HocPhi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab_ThongTinTre;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox imgBox;
        private System.Windows.Forms.Button bt_Them;
        private System.Windows.Forms.GroupBox grp_DSLH;
        private System.Windows.Forms.Button bt_CapNhat;
        private System.Windows.Forms.Button bt_Xoa;
        private System.Windows.Forms.GroupBox grp_TTHS;
        private System.Windows.Forms.DateTimePicker txt_NgayThangNam;
        private System.Windows.Forms.TextBox txt_Ma;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_NgayNhapHoc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_LopHienTai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_DiaChi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_HoTen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tab_XepLop;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox grp_LopHienTai;
        private System.Windows.Forms.ComboBox cbb_LopHienTai;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListView lst_LopHienTai;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.GroupBox grp_LopMoi;
        private System.Windows.Forms.ListView lst_LopMoi;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ComboBox cbb_LopMoi;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button bt_UpAll;
        private System.Windows.Forms.Button bt_Up;
        private System.Windows.Forms.Button bt_Down;
        private System.Windows.Forms.Button bt_Luu;
        private System.Windows.Forms.Button bt_DownAll;
        private System.Windows.Forms.TabPage tab_HocPhi;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button bt_Update;
        private System.Windows.Forms.CheckBox ck_CapNhat;
        private System.Windows.Forms.Button bt_SetHP;
        private System.Windows.Forms.TextBox txt_SoTien;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button bt_HienThi;
        private System.Windows.Forms.ComboBox cbb_Nam;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cbb_Thang;
        private System.Windows.Forms.ComboBox cbb_LopHoc;
        private System.Windows.Forms.DataGridView dgV_HocPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_MaTre;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TenTre;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TenLop;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ThangNam;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_HocPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_TinhTrang;
        private System.Windows.Forms.DataGridViewCheckBoxColumn col_checkHP;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_NgayThu;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DataGridView Gridview1;
        private System.Windows.Forms.TextBox txt_GT;
        private System.Windows.Forms.Label label3;
    }
}